﻿namespace POCWebAppAssignment.Model.DTOs
{
    public class OptionDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
