export const Environment = {
    production: false,
    URI: "http://localhost:5150",
}