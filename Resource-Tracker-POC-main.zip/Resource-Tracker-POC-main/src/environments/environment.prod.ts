export const Environment = {
    production: true,
    URI: "https://resourcetrackerbackendpiyu-dmgefaczfmeyd3hs.canadacentral-01.azurewebsites.net",
}